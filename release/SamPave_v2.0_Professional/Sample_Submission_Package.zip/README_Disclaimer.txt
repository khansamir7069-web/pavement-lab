========================================================================
                           IMPORTANT DISCLAIMER
========================================================================
Submission package is decision-support documentation. Final field execution
requires review and sign-off by a qualified pavement engineer.
========================================================================
